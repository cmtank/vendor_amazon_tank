import sys
from statemachine import StateMachine

class OtterFluidityLabStateMachine(StateMachine):
    """See StateMachine base class in statemachine.py for documentation. It
    will make everything clear (or at least clearer)."""

    NAME = "OtterFluidityLab"
    DESCRIPTION = "Drawing states for FluidityLab application on Otter platform"

    """
    Start tracking earlier with input driver
    This doesn't work very well...

    def START__Touch_AbsPosition2(self, event):
        "Z"
        self.pos = event.e1 * 600 / 2304
        return True

    def Touch_AbsPosition2__Touch_AbsPosition2(self, event):
        if self.pos == event.e1 * 600 / 2304:
            # another event mapping to the same coordinate
            sys.stderr.write("Error in Touch_AbsPosition2 state with self.pos = %s\n" % self.pos)
            return StateMachine.ERROR
        else:
            return False

    def Touch_AbsPosition2__C300_T1(self, event):
        "A"
        return event.e1 == self.pos
    """

    def START__C300_T1(self, event):
        "A"
        self.pos = event.e1
        return True

    def C300_T1__C111_T0(self, event):
        "B"
        return event.e1 == self.pos

    def C111_T0__C111_T1(self, event):
        "C"
        return event.e1 == self.pos

    # Touch events that are discarded may be picked up much later when
    # another touch event happens to have the exact same X position.
    # This time limit will help suppress these spurious readings, which
    # really screw up the statistics.
    @StateMachine.maxElapsed(0.1)
    def C111_T1__C111_T2(self, event):
        "D"
        return event.e1 == self.pos

    def C111_T2__C111_T3(self, event):
        "E"
        return event.e1 == self.pos

    def C111_T3__C111_T3(self, event):
        # this should never happen... we should get ThreadLoopStart first
        sys.stderr.write("Error in C111_T3 state with self.pos = %s\n" % self.pos)
        return StateMachine.ERROR

    def C111_T3__SurfaceFlinger_ThreadLoopStart(self, event):
        "F"
        self.frame = event.e1
        return True

    def SurfaceFlinger_ThreadLoopStart__SurfaceFlinger_ThreadLoopPreSwap(self, event):
        "G"
        return event.e1 == self.frame

    def SurfaceFlinger_ThreadLoopPreSwap__SurfaceFlinger_ThreadLoopPostSwap(self, event):
        "H"
        return event.e1 == self.frame

    def SurfaceFlinger_ThreadLoopPostSwap__SurfaceFlinger_ThreadLoopPrePost(self, event):
        "I"
        return event.e1 == self.frame

    def SurfaceFlinger_ThreadLoopPrePost__SurfaceFlinger_ThreadLoopPostPost(self, event):
        "J"
        return event.e1 == self.frame

    @StateMachine.maxElapsed(0.1)
    def SurfaceFlinger_ThreadLoopPostPost__DssDriver_PixelValue(self, event):
        "K"
        return event.e1 == self.pos

    def DssDriver_PixelValue__DssDriver_PixelValue(self, event):
        # this should never happen... we should get FlipCmdFinish first
        sys.stderr.write("Error in DssDriver_PixelValue state with self.pos = %s, self.frame = %s\n" % (self.pos, self.frame))
        return StateMachine.ERROR

    def DssDriver_PixelValue__DssDriver_FlipCmdFinish(self, event):
        "L"
        return StateMachine.FINISHED
